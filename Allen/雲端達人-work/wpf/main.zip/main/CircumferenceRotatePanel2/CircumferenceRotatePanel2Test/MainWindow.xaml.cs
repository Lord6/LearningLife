﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using DesktopWPFAppLowLevelKeyboardHook;
using System.Runtime.InteropServices;
using System.Diagnostics;
using System.Windows.Forms;

namespace CircumferenceRotatePanel2Test
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {
        private LowLevelKeyboardListener _listener;
        private string kKey="";

        [DllImport("User32.dll")]
        private static extern bool ShowWindowAsync(IntPtr hWnd, int cmdShow);
        [DllImport("User32.dll")]
        private static extern bool SetForegroundWindow(IntPtr hWnd);
        private const int WS_SHOWNORMAL = 1;

        [DllImport("USER32.DLL", CharSet = CharSet.Unicode)]
        public static extern IntPtr FindWindow(string lpClassName, string lpWindowName);
      
       

        public MainWindow()
        {
            InitializeComponent();
           

        }
        void _listener_OnKeyPressed(object sender, KeyPressedArgs e)
        {
            System.Console.WriteLine(e.KeyPressed.ToString());
                if (e.KeyPressed.ToString() == "K")
                {
                    foreach (Process pTarget in Process.GetProcesses())
                    {
                        if (pTarget.ProcessName == "CircumferenceRotatePanel2Test.vshost")  // 取得處理序名稱並與指定程序名稱比較
                        {
                            Console.WriteLine("ProcessName:" + pTarget.ProcessName);
                            HandleRunningInstance(pTarget);
                        }
                    Console.WriteLine("ProcessName:" + pTarget.ProcessName);
                   }
              }
         
        }
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            _listener = new LowLevelKeyboardListener();
            _listener.OnKeyPressed += _listener_OnKeyPressed;
           
             
            
            _listener.HookKeyboard();
           

        }
        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            _listener.UnHookKeyboard();

        }

        public static void HandleRunningInstance(Process instance)
        {
            // 相同時透過ShowWindowAsync還原，以及SetForegroundWindow將程式至於前景
            ShowWindowAsync(instance.MainWindowHandle, WS_SHOWNORMAL);
            SetForegroundWindow(instance.MainWindowHandle);
        }
        private void btn_Click(object sender, RoutedEventArgs e)
        {
            // do something
          //  string content = (sender as Button).Content.ToString();
            //開啟選單程式
            Process.Start(@"C:\Windows\system32\calc.exe");
            //視窗縮小
            WindowState = WindowState.Minimized;

        }
        private void test_Click(object sender, RoutedEventArgs e)
        {
          
            //  string content = (sender as Button).Content.ToString();
            //開啟選單程式
            IntPtr calculatorHandle = FindWindow("CalcFrame", "小算盤");

            // Verify that Calculator is a running process.
            if (calculatorHandle == IntPtr.Zero)
            {
          //    MessageBox.Show("Calculator is not running.");
                return;
            }
            SetForegroundWindow(calculatorHandle);
        
            SendKeys.SendWait("2");

          
            //視窗縮小
            WindowState = WindowState.Minimized;

        }
      


    }
}
